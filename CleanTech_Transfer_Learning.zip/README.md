# CleanTech: Transforming Waste Management with Transfer Learning

Project using transfer learning to classify blood cell images.